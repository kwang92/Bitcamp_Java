package bank;

public class Customer_Main {
	public static void main(String[] args) {
		Customer_GUI cui = new Customer_GUI("류광민","1010", "1234");
	}
}