package list;

public class MyList<E>{	// 임의의 데이터타입을 넣을 수 있도록 작성 ( 제네릭 )
	// add(E), remove(index), get(index), size(), set(int, E)
	private E[] array;
	private int size;
	public MyList() {
		array = (E[])new Object[0];
		size = 0;
	}
	
	public void set(int index, E data) {
		// index 위치에 data 삽입
		E[] tmp = (E[])new Object[size+1];
		int pos = 0;
		
		for(int i = 0; i < size(); i++) {
			if(index == i) {
				pos++;
			}
			tmp[i+pos] = this.array[i];
		}
		tmp[index] = data;
		array = tmp;
		size++;
	}
	public void add(E data) {
		E[] tmp = (E[])new Object[size+1];
		
		for(int i = 0; i < size(); i++) {
			tmp[i] = this.array[i];
		}
		tmp[size()] = data;
		array = (E[])new Object[size+1];
		array = tmp;
		
		size++;
	}
	public void remove(int index) {
		// index 삭제하고 뒤 배열 내용 앞으로 한칸씩
		E[] tmp = (E[])new Object[size-1];
		int pos = 0;
		
		for(int i = 0; i < size-1; i++) {
			if(i == index)
				pos++;
			tmp[i] = array[i + pos];
		}
		array = tmp;
		size--;
		
	}
	public E get(int index) {
		return this.array[index];
	}
	public int size() {
		return size;
	}
}
