package list;

public class ListTest {
	public static void main(String[] args) {
		// List -> interface
		// ArrayList, LinkedList -> List 구현 클래스
		MyManagement2 mm = new MyManagement2();
		mm.start();
		
	}
}
